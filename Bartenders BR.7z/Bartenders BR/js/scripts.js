function openModal() {
    document.getElementById("myModal").style.display = "block";
}

function closeModal() {
    document.getElementById("myModal").style.display = "none";
}



function redirectToBartenders() {
    window.location.href = "bartenders.html";
}


