function openModal() {
    document.getElementById("myModal").style.display = "block";
}

function closeModal() {
    document.getElementById("myModal").style.display = "none";
}

function openModalCAI() {
    document.getElementById("myModalCAI").style.display = "block";
}

function closeModalCAI() {
    document.getElementById("myModalCAI").style.display = "none";
}

function openModalVOD() {
    document.getElementById("myModalVOD").style.display = "block";
}

function closeModalVOD() {
    document.getElementById("myModalVOD").style.display = "none";
}

function openModalWHI() {
    document.getElementById("myModalWHI").style.display = "block";
}

function closeModalWHI() {
    document.getElementById("myModalWHI").style.display = "none";
}

function openModalGIN() {
    document.getElementById("myModalGIN").style.display = "block";
}

function closeModalGIN() {
    document.getElementById("myModalGIN").style.display = "none";
}

function openModalMOJ() {
    document.getElementById("myModalMOJ").style.display = "block";
}

function closeModalMOJ() {
    document.getElementById("myModalMOJ").style.display = "none";
}

function openModalRUM() {
    document.getElementById("myModalRUM").style.display = "block";
}

function closeModalRUM() {
    document.getElementById("myModalRUM").style.display = "none";
}

function openModalCARLOS() {
    document.getElementById("myModalCARLOS").style.display = "block";
}

function closeModalCARLOS() {
    document.getElementById("myModalCARLOS").style.display = "none";
}

function openModalCER() {
    document.getElementById("myModalCER").style.display = "block";
}

function closeModalCER() {
    document.getElementById("myModalCER").style.display = "none";
}

function openModalVIN() {
    document.getElementById("myModalVIN").style.display = "block";
}

function closeModalVIN() {
    document.getElementById("myModalVIN").style.display = "none";
}

function openModalJOAO() {
    document.getElementById("myModalJOAO").style.display = "block";
}

function closeModalJOAO() {
    document.getElementById("myModalJOAO").style.display = "none";
}

function openModalLEO() {
    document.getElementById("myModalLEO").style.display = "block";
}

function closeModalLEO() {
    document.getElementById("myModalLEO").style.display = "none";
}

function openModalJEN() {
    document.getElementById("myModalJEN").style.display = "block";
}

function closeModalJEN() {
    document.getElementById("myModalJEN").style.display = "none";
}

function openModalGAB() {
    document.getElementById("myModalGAB").style.display = "block";
}

function closeModalGAB() {
    document.getElementById("myModalGAB").style.display = "none";
}

function openModalGABE() {
    document.getElementById("myModalGABE").style.display = "block";
}

function closeModalGABE() {
    document.getElementById("myModalGABE").style.display = "none";
}

function openModalANA() {
    document.getElementById("myModalANA").style.display = "block";
}

function closeModalANA() {
    document.getElementById("myModalANA").style.display = "none";
}

function openModalCAR() {
    document.getElementById("myModalCAR").style.display = "block";
}

function closeModalCAR() {
    document.getElementById("myModalCAR").style.display = "none";
}

function redirectToBartenders() {
    window.location.href = "bartenders.html";
}


var formSignin = document.querySelector('#signin')
var formSignup = document.querySelector('#signup')
var btnColor = document.querySelector('.btnColor')

document.querySelector('#btnSignin')
  .addEventListener('click', () => {
    formSignin.style.left = "25px"
    formSignup.style.left = "450px"
    btnColor.style.left = "0px"
})

document.querySelector('#btnSignup')
  .addEventListener('click', () => {
    formSignin.style.left = "-450px"
    formSignup.style.left = "25px"
    btnColor.style.left = "110px"
})